import random
from functools import reduce
import csv


def convert(lst):
    return (lst[0].split())

file = open("wordle_words.csv")
csvreader = csv.reader(file)
word_choice = []
for row in csvreader:
    word_choice.append(row)
file.close()        
print("---------------------------------")
word = random.choices(word_choice, k = 1)
list_to_str = ' '.join([str(elem) for elem in word])
word_sep = list(list_to_str)
del word_sep[7:-1]
del word_sep[0:2]                    
user_word = []
Letters = []
Letters2 = []
loops = 1
guesses = 6
while loops < 8:
        user_word.append( input(str("What is your guess?  ")))
        
        list_to_str2 = ' '.join([str(elem) for elem in user_word])
        user_word = list(list_to_str2)
        if len(user_word) !=  5 :
            print("That word isn't 5 letters, you have", guesses,"guesses left")
            user_word.clear()
        else:
       
                if user_word[0:4] == word_sep[0:4]:
                    print("well done you guessed it in", loops, "guesses")
                    loops += 20
                else:         
                    print("Try again, you have", guesses, "guesses left")
                    same_letter0 = word_sep.count(user_word[0])
                    same_letter1 = word_sep.count(user_word[1])
                    same_letter2 = word_sep.count(user_word[2])
                    same_letter3 = word_sep.count(user_word[3])
                    same_letter4 = word_sep.count(user_word[4]) 
                    if same_letter0 == 1 or same_letter0 == 2:
                        if user_word[0] not in Letters2:
                            Letters2.append(user_word[0])
                    if same_letter1 == 1 or same_letter1 == 2:
                        if user_word[1] not in Letters2:
                            Letters2.append(user_word[1])
                    if same_letter2 == 1 or same_letter2 == 2:
                        if user_word[2] not in Letters2:
                            Letters2.append(user_word[2])
                    if same_letter3 == 1 or same_letter3 == 2:
                        if user_word[3] not in Letters2:
                            Letters2.append(user_word[3])
                    if same_letter4 == 1 or same_letter4 == 2:
                        if user_word[4] not in Letters2:
                            Letters2.append(user_word[4])
                    print(user_word)  
                    bool_list = list(map(lambda x, y: x == y, word_sep, user_word))
                    print(bool_list)
                    for item in user_word:
                        if item not in Letters:
                            Letters.append(item)
                    Letters.sort()
                    Letters2.sort()
                    user_word.clear()
                    print("Letters used:  ", Letters)
                    print("Letters in the word:  ", Letters2)
                    print("---------------------------------")
        
        
        guesses -= 1    
        loops += 1
        
print("your word was", word_sep)
input("Type done if you are finished playing    ")